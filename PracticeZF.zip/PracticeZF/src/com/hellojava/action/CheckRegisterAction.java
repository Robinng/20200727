package com.hellojava.action;

import java.io.IOException;

import org.apache.struts2.ServletActionContext;
import org.apache.struts2.convention.annotation.Action;

import org.apache.struts2.convention.annotation.Result;

import org.apache.struts2.convention.annotation.Results;

import com.hellojava.web.Entity.User;
import com.hellojava.web.business.UserService;
import com.opensymphony.xwork2.ActionSupport;

	/**
	 * ����CheckRegisterAction.action
	 * 
	 *@author ZF
	 *@version 2016/9
	 */
@Results({ @Result(location = "index.jsp", name = "success"),
	@Result(location = "register.jsp", name = "input") })
public class CheckRegisterAction extends ActionSupport {
	
	private static final long serialVersionUID = 1L;
	
	/** �û���ʵ�� */
	private User user = new User();	
	
	private String userName1;
	
	/**
	 * @return the userName
	 */
	public String getUserName() {
		return userName1;
	}

	/**
	 * @param userName the userName to set
	 */
	public void setUserName(String userName1) {
		this.userName1 = userName1;
	}

	/** �û�ȷ������ */
	private String newUserPwd;
	
	/**
     * ���ȷ������
     * 
     * @return newUserPwd
     */
	public String getNewUserPwd() {
		return newUserPwd;
	}

	/**
     * ����ȷ�������ֵ
     * 
     * newUserPwd�� ����newUserPwd
     * @return
     */
	public void setNewUserPwd(String newUserPwd) {
		this.newUserPwd = newUserPwd;
	}

	/**
     * ���user
     * 
     * @return User
     */
	public User getUser() {
		return user;
	}
	
	/**
     * ����user��ֵ
     * 
     * user�� ����user
     * @return
     */
	
	public void setUser(User user) {
		this.user = user;
	}
	

	/**
	 * registerҳ���½����CheckRegisterAction����execute��������ҳ�浼����У��
	 * 
	 * 
	 * @return string
	 */
	
	@Action("checkregister")
	public String execute() {
		return "success";
	}
	
	/**
	 * ��ѯ�û��Ƿ����
	 * 
	 * 
	 * @return string
	 */
	@Action(value="checkUser",
			results={
					@Result(location="register.jsp",name="success"),
					@Result(location="register.jsp",name="error")
			})
	public String CheckUser() {
		UserService userService = new UserService();
		user.setUserName(userName1);
		boolean bool = userService.checkUser(this.user);
		if(bool) {
			try {
				ServletActionContext.getResponse().getWriter().println(1);
			} catch (IOException e) {				
				e.printStackTrace();
			}
		}else{
			try {
				ServletActionContext.getResponse().getWriter().println(0);
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		try {
			ServletActionContext.getResponse().getWriter().flush();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return bool?"success":"error";
	}
}
