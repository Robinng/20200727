package com.hellojava.action;

import org.apache.struts2.convention.annotation.Action;

import org.apache.struts2.convention.annotation.Namespace;

import org.apache.struts2.convention.annotation.Result;

import com.hellojava.web.Entity.User;

import com.opensymphony.xwork2.ActionSupport;

	/**
	 * ����register.action
	 * 
	 *@author ZF
	 *@version 2016/9
	 */
public class RegisterAction extends ActionSupport {
	
	/** �û���ʵ�� */
	private User user = new User();
	
	/**
     * ���user
     * 
     * @return User user
     */
	public User getUser() {
		return user;
	}
	
	/**
     * ����user��ֵ
     * 
     * user, ����user
     * @return
     */
	
	public void setUser(User user) {
		this.user = user;
	}
	
	/**
	 * ����register.action����execute�������ҳ�浼��
	 * 
	 * 
	 * @return string
	 */
	
	@Action(value="register", 
			results={
				@Result(location="register.jsp",name=SUCCESS)
				})
	public String execute(){
		return SUCCESS;
	}
	

}
