package com.hellojava.action;

import org.apache.struts2.convention.annotation.Action;

import org.apache.struts2.convention.annotation.Result;

import org.apache.struts2.convention.annotation.Results;

import com.hellojava.web.Entity.User;

import com.opensymphony.xwork2.ActionSupport;

	/**
	 * ����login.action
	 * 
	 *@author ZF
	 *@version 2016/9
	 */
@Results({ @Result(location = "search.jsp", name = "success"),
		@Result(location = "login.jsp", name = "input") })
public class LoginAction extends ActionSupport {

	private static final long serialVersionUID = 1L;

	/** �û���ʵ�� */
	private User user = new User();
	
    /**
     * ���user
     * 
     * @return User
     */
	public User getUser() {
		return user;
	}
	
	/**
     * ����user��ֵ
     * 
     * user�� ����user
     * @return
     */
	
	public void setUser(User user) {
		this.user = user;
	}

	/**
	 * loginҳ���½����TestAction����execute����,"success"��ת��search.jsp���д�����Ϣ��input��ͼ
	 * 
	 * 
	 * @return string
	 */
	@Action("login")
	public String execute() {
		return "success";
	}

}
