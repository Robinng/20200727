package com.hellojava.web.database.dao;

import java.sql.Connection;

import java.sql.ResultSet;

import java.sql.SQLException;

import com.hellojava.web.Entity.User;

import com.hellojava.web.database.DBManager;

	/**
	 * ����UserDao
	 * 
	 *@author ZF
	 *@version 2016/9
	 */

public class UserDao {
	
	/**
	 * ��ѯ�û�
	 * 
	 * user, �����ı���������û�
	 * @return User user
	 */
	public User loadUserByName(User user)throws SQLException {
		User u=null;
		String sql="select * from users where userName=? and userPwd=?";
		Connection conn = DBManager.openConnection();
		Object[] obs = {user.getUserName(),user.getUserPwd()};
		ResultSet rs = DBManager.query(conn, sql, obs);
		if (rs.next()) {
			u = new User();
			u.setUserId(rs.getInt("userId"));
			u.setUserName(rs.getString("userName"));
			u.setUserPwd(rs.getString("userPwd"));
		}
		DBManager.closeConnection(conn);
		return u;
	}
	
	public int save(User user)throws SQLException {
		int count = 0;
		String sql = "insert into users(userName,userpwd,userPhoneNum,userEmail) values(?,?,?,?)";
		Connection conn = DBManager.openConnection();
		Object[] obs = {user.getUserName(),user.getUserPwd(),user.getUserPhoneNum(),user.getUserEmail()};
		count = DBManager.update(conn, sql, obs);
		DBManager.closeConnection(conn);
		return count;
	}
}
