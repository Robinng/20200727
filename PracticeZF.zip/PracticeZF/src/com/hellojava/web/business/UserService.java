package com.hellojava.web.business;

import java.sql.SQLException;

import com.hellojava.web.Entity.User;

import com.hellojava.web.database.dao.UserDao;


	/**
	 * ����UserService
	 * 
	 *@author ZF
	 *@version 2016/9
	 */

public class UserService {
	
	/** ����UserDao */
	private UserDao userDao = new UserDao();
	
	/**
	 * ��ѯ�û�
	 * 
	 * user, �����ı���������û�
	 * @return boolean
	 */
	public boolean checkUser(User user) {
		boolean bool = false;
		User u = null;
		try {
			u = userDao.loadUserByName(user);
			if (u!=null) {
				bool=true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return bool;
	}

	/**
	 * �����û�
	 * 
	 * user, �����û���ע����Ϣ
	 * @return boolean
	 */
	public boolean save(User user) {
		boolean bool = false;
		try {
			int count = userDao.save(user);
			if(count>0) {
				bool=true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return bool;
	}
}
